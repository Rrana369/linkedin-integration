<?php
$servername = "localhost";
$username = "id2372351_seenonth_pdfpars";
$password = "Sai541**";
$db_name = "id2372351_seenonth_pdfparser";

