<?php
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
session_start();
if(isset($_SESSION['pswd1']) && $_SESSION['pswd1']!=""){
	$_SESSION['admin']= $_SESSION['pswd1'];
}
if(!isset($_SESSION['admin']) && $_SESSION['admin'] ==""){
	header('location:../index.php');
}
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
</head>
<body>
	<div class="menu_admin">
	<!--<a href="pdfreader.php" class="edit_btn" >PDF reader</a>-->
	<a href="admin-role.php" class="edit_btn" >Manage Roles</a>
	<a href="admin-keyword.php" class="edit_btn" >Manage Keywords</a>
	<a href="admin-skill.php" class="edit_btn" >Manage Skill</a>
	<a href="display-result.php" class="edit_btn" >Display Result</a>
	<a href="add-massage.php" class="edit_btn" >Manage Massage</a>
	<a href="connection.php" class="edit_btn" >Create Database and table</a>
	<a href="logout.php" class="edit_btn" >Logout</a>
	</div>
	<?php if (isset($_SESSION['message'])): ?>
		<div class="msg">
			<?php 
				echo $_SESSION['message']; 
				unset($_SESSION['message']);
			?>
		</div>
	<?php endif ?>