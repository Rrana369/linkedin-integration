<?php
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	
	<!--<a href="pdfreader.php" class="edit_btn" >PDF reader</a>
	<!--<a href="admin-role.php" class="edit_btn" >Manage Roles</a>
	<a href="admin-keyword.php" class="edit_btn" >Manage Keywords</a>
	<a href="connection.php" class="edit_btn" >Create Database and table</a>-->
	
	<?php if (isset($_SESSION['message'])): ?>
		<div class="msg">
			<?php 
				echo $_SESSION['message']; 
				unset($_SESSION['message']);
			?>
		</div>
	<?php endif ?>