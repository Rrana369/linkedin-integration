<?php 
include('skill-server.php');
if (isset($_GET['edit'])) {
	$id = $_GET['edit'];
	$update = true;
	$record = mysqli_query($db, "SELECT * FROM skill WHERE id=$id");
	$nums=mysqli_num_rows($record);
	if ($nums == 1 ) {
		$n = mysqli_fetch_array($record);
		$name = $n['name'];
	}

}
?>

<?php include( '../include/header_admin.php' ); ?>

<?php
$results = mysqli_query($db, "SELECT * FROM skill ORDER BY id DESC"); ?>

<form method="post" action="skill-server.php" >

	<input type="hidden" name="id" value="<?php echo $id; ?>">

	<div class="input-group">
		<label>Enter Skill</label>
		<input type="text" name="name" value="<?php echo $name; ?>">
	</div>
	<div class="input-group">

		<?php if ($update == true): ?>
			<button class="btn" type="submit" name="update" style="background: #556B2F;" >update</button>
		<?php else: ?>
			<button class="btn" type="submit" name="save" >Save</button>
		<?php endif ?>
	</div>
</form>

<table>
	<thead>
		<tr>
			<th>Skill</th>
			<th colspan="2">Action</th>
		</tr>
	</thead>
	
	<?php if( !empty( $results ) ) {
	while ($row = mysqli_fetch_array($results)) { ?>
		<tr>
			<td><?php echo $row['name']; ?></td>
			<td>
				<a href="admin-skill.php?edit=<?php echo $row['id']; ?>" class="edit_btn" >Edit</a>
			</td>
			<td>
				<a href="skill-server.php?del=<?php echo $row['id']; ?>" class="del_btn">Delete</a>
			</td>
		</tr>
	<?php } 
		} ?>
</table>

<?php include( '../include/footer.php' ); ?>