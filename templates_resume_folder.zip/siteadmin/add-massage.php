<?php 
session_start();
include( '../include/header_admin.php' );
include( '../include/config.php' );
$db = mysqli_connect($servername, $username, $password, $db_name);
if(isset($_REQUEST['update']) && $_REQUEST['update'] !=""){
	
	mysqli_query($db,"UPDATE massage SET massage='".$_POST['massage']."' WHERE id='1'");
	$_SESSION['message'] = "Massage update successfully."; 
}

 ?>

<?php
$results = mysqli_query($db, "SELECT * FROM massage WHERE id =1"); 
$row = mysqli_fetch_array($results);
?>

<form method="post" action="add-massage.php" >
<?php
if(isset($_SESSION['message'])){
	echo '<span style="color:green">'.$_SESSION['message'].'</span>';
	unset($_SESSION['message']);
}
	?>
	<div class="input-group">
		<label>Enter Massage</label>
		<input type="text" name="massage" value="<?php echo $row['massage']; ?>">
	</div>
	<div class="input-group">
		<button class="btn" type="submit" name="update" style="background: #556B2F;" value="update">update</button>	
	</div>
</form>

<?php include( '../include/footer.php' ); ?>