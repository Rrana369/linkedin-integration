<?php include('../include/header_admin.php');?>
<form method="post" action="dologin.php" >
	<div>Welcome to pdfPaser admin panel</div>
</form>

<?php include('../include/footer.php')?>
