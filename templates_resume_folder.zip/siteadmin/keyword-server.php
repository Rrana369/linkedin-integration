<?php 
	session_start();
	include( '../include/config.php' );
	$db = mysqli_connect($servername, $username, $password, $db_name);

	// initialize variables
	$name = "";
	$id = 0;
	$update = false;

	if (isset($_POST['save'])) {
		$name = $_POST['name'];
		$role_id = $_POST['role_id'];
		if( !empty( $name ) ) {
			mysqli_query($db, "INSERT INTO keywords (role_id, name) VALUES ('$role_id','$name')"); 
			$_SESSION['message'] = "saved"; 
		} else {
			$_SESSION['message'] = "Empty role not allowed"; 
		}
		header('location: admin-keyword.php');

	}


	if (isset($_POST['update'])) {
		$id = $_POST['id'];
		$name = $_POST['name'];

		if( !empty( $name ) ) {
			mysqli_query($db, "UPDATE keywords SET name='$name' WHERE id=$id");
			$_SESSION['message'] = "updated!"; 
		} else {
			$_SESSION['message'] = "Empty role not allowed"; 
		}
		header('location: admin-keyword.php');
	}

if (isset($_GET['del'])) {
	$id = $_GET['del'];
	mysqli_query($db, "DELETE FROM keywords WHERE id=$id");
	$_SESSION['message'] = "deleted!"; 
	header('location: admin-keyword.php');
}


$results = mysqli_query($db, "SELECT * FROM keywords");


?>