<?php
if(isset($_REQUEST['msg'])){
$msg = $_REQUEST['msg'];
}
?>
<link rel="stylesheet" type="text/css" href="../css/style.css">
<form method="post" action="dologin.php" >
<?php



if(isset($msg) && $msg=="true"){
	echo '<h3 style="color:red;">Invalid login please enter valid password</h3>';
}
?>
	<div>Enter Your Password </div>
	<div class="input-group">
		<input type="password" name="password" id="password" placeholder="Enter password" required>	
	</div>
	<div class="input-group">
		<button class="btn" type="submit" name="login" >Login</button>	
	</div>
</form>

<?php include('../include/footer.php')?>
