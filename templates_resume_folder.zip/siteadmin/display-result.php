<?php include( '../include/header_admin.php' ); 
include( '../include/config.php' );
	$db = mysqli_connect($servername, $username, $password, $db_name);
?>

<?php
$results = mysqli_query($db, "SELECT * FROM result_data ORDER BY ID DESC"); ?>

<table>
	<thead>
		<tr>
			<th>File Name</th>
			<th>Email</th>
			<th>Location</th>
			<th>Industry</th>
			<th>Phone</th>
			<th>Skills</th>
			<th>Graduation year</th>
			<th>Percentage</th>
			<th>Role</th>
			<th>Status</th>
		</tr>
	</thead>
	
	<?php if( !empty( $results ) ) {
	while ($row = mysqli_fetch_array($results)) { ?>
		<tr>
			<td><?php if($row['filename'] !="") {echo '<a href="../pdf/'.$row['filename'].'" target="_blank">'.$row['filename'].'</a>';}else{echo '-';} ?></td>
			<td><?php if($row['email'] !=""){echo $row['email'];}else{echo '-';} ?></td>
			<td><?php if($row['location'] !=""){echo $row['location'];}else{echo '-';} ?></td>
			<td><?php if($row['industry'] !=""){echo $row['industry'];}else{echo '-';} ?></td>
			<td><?php if($row['number'] != ''){echo $row['number'];}else{echo '-';} ?></td>
			<td><?php if($row['skills'] != ''){echo $row['skills'];}else{echo '-';} ?></td>
			<td><?php if($row['year'] != ''){echo $row['year'];}else{echo '-';} ?></td>
			<td><?php if($row['percentage']){echo $row['percentage'].'%';}else{echo '-';} ?></td>
			<td><?php if($row['role_id'] !=''){
				$resrole = mysqli_query($db, "SELECT name FROM roles WHERE id='".$row['role_id']."'");
				$rowrole = mysqli_fetch_array($resrole);
				echo $rowrole['name'];
				
			}else{echo '-';} ?></td>
			<td><?php if($row['status'] !=''){echo $row['status'];}else{echo '-';} ?></td>
			
		</tr>
	<?php } 
		} ?>
</table>
<style>
table{
	width:100%;
}
</style>
<?php include( '../include/footer.php' ); ?>