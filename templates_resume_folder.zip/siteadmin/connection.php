<?php
include( '../include/header_admin.php' );
include( '../include/config.php' );

// Create connection
$db = new mysqli($servername, $username, $password);

// Check connection
if ($db->connect_error) {
	echo "Please update Database credentials in config.php file.<br/>";
    die("Connection failed: " . $db->connect_error);
} else {

	$sql = "CREATE DATABASE IF NOT EXISTS $db_name";
	$db->query($sql);

	$sql = "CREATE TABLE IF NOT EXISTS {$db_name}.roles (
			  id int(11) NOT NULL AUTO_INCREMENT,
			  name varchar(500) NOT NULL,
			  PRIMARY KEY (id)
			);
			";
	$db->query($sql);

	$sql = "CREATE TABLE IF NOT EXISTS {$db_name}.keywords (
			  id int(11) NOT NULL AUTO_INCREMENT,
			  role_id int(11) NOT NULL,
			  name varchar(500) NOT NULL,
			  PRIMARY KEY (id),
			  KEY RoleID (role_id)
			);
			";
	$db->query($sql);

	$resulttale = "CREATE TABLE IF NOT EXISTS {$db_name}.result_data (`id` int(11) NOT NULL AUTO_INCREMENT,`role_id` int(11) DEFAULT NULL,`filename` varchar(255) DEFAULT NULL,`email` varchar(255) DEFAULT NULL,`location` varchar(50) NOT NULL, `industry` varchar(100) NOT NULL,`number` varchar(255) DEFAULT NULL,`percentage` float(10,2) DEFAULT NULL,`skills` varchar(255) DEFAULT NULL,`year` varchar(255) DEFAULT NULL,`created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,`status` varchar(255) DEFAULT NULL,PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=latin1";
	$db->query($resulttale);
	
	$admintable = "CREATE TABLE IF NOT EXISTS {$db_name}.admin (`id` int(11) NOT NULL AUTO_INCREMENT,`username` varchar(255) DEFAULT NULL,`password` varchar(255) DEFAULT NULL,`login_date` datetime DEFAULT NULL,`created_At` datetime DEFAULT NULL,PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=latin1";
	$db->query($admintable);
	
	$Insert = "INSERT INTO {$db_name}.admin(`username`, `password`, `login_date`, `created_At`) VALUES ('admin','d9ad64187a5e868d43c8046d6919260c','".date('Y-m-d H:i:s')."','".date('Y-m-d H:i:s')."')";
	$db->query($insert);
	
	
	$unsertmsg = "CREATE TABLE IF NOT EXISTS {$db_name}.massage (`id` int(11) NOT NULL AUTO_INCREMENT,`massage` text,PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=latin1";
	$db->query($unsertmsg);
	
	$insertmsg = "INSERT INTO `massage` (`id`, `massage`) VALUES ('1', 'We are working on a qualitative analysis for you ready in 24 hours.')";
	$db->query($insertmsg);
	
	
	echo "<br /><br /><br />Database and tables created successfully";
}
?>

<?php include( '../include/footer.php' ); ?>