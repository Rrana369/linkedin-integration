<?php 
include('keyword-server.php');
if (isset($_GET['edit'])) {
	$id = $_GET['edit'];
	$update = true;
	$record = mysqli_query($db, "SELECT * FROM keywords WHERE id=$id");
	$nums=mysqli_num_rows($record);
	if ($nums == 1 ) {
		$n = mysqli_fetch_array($record);
		$name = $n['name'];
	}
}

include( '../include/header_admin.php' );

$results = mysqli_query($db, "SELECT k.id, k.name as name, r.name as role_name FROM keywords As k
								LEFT JOIN roles As r ON k.role_id = r.id 
								ORDER BY k.id DESC"); ?>

<form method="post" action="keyword-server.php" >

	<input type="hidden" name="id" value="<?php echo $id; ?>">
	
	<?php $roles = mysqli_query($db, "SELECT * FROM roles ORDER BY name ASC"); ?>
	<div class="input-group">
		<?php if( empty( $_GET['edit'] ) ) { ?>
			<label>Select Role</label>
			<select name="role_id" required>
			<option value="">Please select role</option>
			<?php if( !empty( $roles ) ) {
				while ($row = mysqli_fetch_array($roles)) { ?>
					<option value="<?php echo $row['id']; ?>"><?php echo $row['name']; ?></option>
			<?php }
			} ?>
			</select>
		<?php } ?>
	</div>

	<div class="input-group">
		<label>Enter keyword</label>
		<input type="text" name="name" value="<?php echo $name; ?>">
	</div>
	<div class="input-group">

		<?php if ($update == true): ?>
			<button class="btn" type="submit" name="update" style="background: #556B2F;" >update</button>
		<?php else: ?>
			<button class="btn" type="submit" name="save" >Save</button>
		<?php endif ?>
	</div>
</form>

<table>
	<thead>
		<tr>
			<th>Keyword</th>
			<th>Role</th>
			<th colspan="2">Action</th>
		</tr>
	</thead>
	
	<?php if( !empty( $results ) ) {
	while ($row = mysqli_fetch_array($results)) { ?>
		<tr>
			<td><?php echo $row['name']; ?></td>
			<td><?php echo $row['role_name']; ?></td>
			<td>
				<a href="admin-keyword.php?edit=<?php echo $row['id']; ?>" class="edit_btn" >Edit</a>
			</td>
			<td>
				<a href="keyword-server.php?del=<?php echo $row['id']; ?>" class="del_btn">Delete</a>
			</td>
		</tr>
	<?php } 
		} ?>
</table>

<?php include( '../include/footer.php' ); ?>