<?php
include( '../include/config.php' );
session_start();
$db = mysqli_connect($servername, $username, $password, $db_name);


$password = $_REQUEST['password'];

$login = 'SELECT id,password FROM admin WHERE password="'.md5($_REQUEST['password']).'"';
$res = mysqli_query($db,$login);
$nums = mysqli_num_rows($res);

if($nums > 0){
$rows = mysqli_fetch_array($res);
$_SESSION['pswd1'] = $rows['password'];
header('location:dashboard.php');
exit;
}
else{
	header('location:index.php?msg=true');
	exit;
	
}
?>